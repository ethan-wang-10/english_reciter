import json

import question_authoring as authoring
import simple_web_app as web

service = authoring.QuestionAuthoringService(web.gaokao_question_sources, web._current_gaokao_source)
for kind, worker in (
    ("generation", "codex-legacy-oct02-new-author"),
    ("revision", "codex-legacy-oct09-author"),
    ("recognition_blind", "codex-legacy-oct01-recognition"),
    ("context_blind", "codex-legacy-oct01-context"),
    ("feedback", "codex-legacy-oct01-feedback"),
):
    pending = service.pending({"kind": kind, "worker_id": worker, "level": "", "limit": 10, "ttl_seconds": 86400})
    names = []
    for item in pending["items"]:
        source = item.get("source", {})
        names.append(source.get("english") or item.get("headword") or item.get("prompt"))
    print(json.dumps({"kind": kind, "count": len(names), "has_more": pending["has_more"], "items": names}, ensure_ascii=False))
