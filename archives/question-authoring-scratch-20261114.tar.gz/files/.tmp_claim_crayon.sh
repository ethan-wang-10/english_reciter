#!/bin/sh
set -eu
ssh -4 -o BatchMode=yes -o ConnectTimeout=15 root@english.itorange.online 'cd /data/english_reciter && PYTHONPATH=.:scripts /data/english_reciter/.venv/bin/python -B -c '"'"'
import json, sqlite3, time
import question_authoring_client as client
db = sqlite3.connect("/data/english_reciter/user_data_simple/sessions.sqlite3")
token = db.execute("SELECT token FROM auth_sessions WHERE session_kind=? AND expires_at>? ORDER BY expires_at DESC LIMIT 1", ("admin", time.time())).fetchone()[0]
query = {"kind":"recognition_blind","worker_id":"codex-legacy-oct11-recognition-a","level":"","limit":10,"ttl_seconds":86400}
try:
    output = client.request_json(client.DEFAULT_BASE_URL, token, "GET", client.API_ROOT + "/pending", query=query, timeout=120)
except client.ClientError as error:
    output = error.response or {"error": str(error)}
print(json.dumps(output, ensure_ascii=False))
'"'"'' > /private/tmp/pending-recognition-9.json
