import json
import sqlite3
import sys
import time

sys.path[:0] = [".", "scripts"]
import question_authoring_client as client

kind, worker_id, request_id, words_json = sys.argv[1:]
db = sqlite3.connect("user_data_simple/sessions.sqlite3")
row = db.execute(
    "select token from auth_sessions where session_kind='admin' and expires_at>? order by expires_at desc limit 1",
    (time.time(),),
).fetchone()
if row is None:
    raise SystemExit("no active admin session")
try:
    payload = client.request_json(
        client.DEFAULT_BASE_URL,
        row[0],
        "POST",
        client.API_ROOT + "/claims",
        body={
            "kind": kind,
            "worker_id": worker_id,
            "request_id": request_id,
            "level": "",
            "limit": 10,
            "ttl_seconds": 86400,
            "words": json.loads(words_json),
        },
        timeout=120,
    )
except client.ClientError as exc:
    print(json.dumps(exc.response or {"error": str(exc)}, ensure_ascii=False))
    raise SystemExit(2)
print(json.dumps(payload, ensure_ascii=False))
