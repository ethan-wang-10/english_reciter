import json
from pathlib import Path

root = Path('output/question-authoring/legacy-20261001/legacy_revision')
extra = {
 'vcd': ('During the 1990s, families often used a VCD player to watch films before streaming services became widely available.', '在流媒体普及前，20世纪90年代家庭常用VCD播放器观看电影。', ['DVD','radio','camera','cassette','printer','scanner'], ['数字光盘','收音机','相机','磁带','打印机','扫描仪']),
 'vehicle': ('The vehicle stopped at the red light while pedestrians crossed the city intersection under the traffic officer’s direction.', '交通警察指挥下行人过城市路口时，车辆在红灯处停下。', ['building','container','organ','instrument','garment','machine'], ['建筑物','容器','器官','仪器','衣物','机器']),
 'veil': ('At the wedding, the bride lifted her white veil before kissing the groom in front of guests.', '婚礼上，新娘在宾客面前亲吻新郎前掀起白色面纱。', ['mask','scarf','hat','curtain','glove','blanket'], ['面具','围巾','帽子','窗帘','手套','毯子']),
 'velocity': ('The rocket increased its velocity after the engines ignited, covering the measured distance much faster than before.', '发动机点火后火箭速度增加，飞过测量距离的速度比之前快得多。', ['volume','weight','temperature','density','altitude','duration'], ['体积','重量','温度','密度','高度','持续时间']),
 'velvet': ('The costume designer chose red velvet for the theater curtain because its dense surface absorbed light and looked luxurious.', '服装设计师为剧院幕布选择红色天鹅绒，因为其致密表面吸光且显得豪华。', ['cotton','leather','linen','plastic','rubber','canvas'], ['棉布','皮革','亚麻','塑料','橡胶','帆布']),
 'velvety': ('The chef described the chocolate mousse as velvety because its smooth texture dissolved gently on the tongue.', '厨师称巧克力慕斯有天鹅绒般质地，因为其顺滑口感在舌头上轻柔融化。', ['grainy','rough','bitter','watery','crunchy','fibrous'], ['颗粒状的','粗糙的','甜腻的','水状的','脆爽的','纤维状的']),
 'venal': ('The venal official accepted money from contractors and secretly altered the permit records for the construction project.', '那个贪污的官员收受承包商钱财，暗中篡改了建设项目的许可记录。', ['honest','generous','fragile','sleepy','musical','curious'], ['诚实的','慷慨的','脆弱的','困倦的','音乐的','好奇的']),
 'vendor': ('The street vendor arranged baskets of fresh fruit beside the market entrance and called out prices to passing customers.', '街头小贩在市场入口摆放新鲜水果篮，并向经过的顾客喊价。', ['customer','doctor','sailor','farmer','lawyer','pilot'], ['顾客','医生','水手','农民','律师','飞行员']),
 'veneer': ('The cabinet appeared to be solid walnut, but its thin veneer covered cheaper wood beneath the polished surface.', '橱柜看似实心胡桃木，但抛光表面下的饰面薄板覆盖着更便宜的木材。', ['foundation','hinge','handle','cushion','marble','brick'], ['地基','铰链','把手','坐垫','大理石','砖块']),
 'venerable': ('The venerable professor received a standing ovation after decades of careful research and generous mentorship.', '这位德高望重的教授经过数十年严谨研究和慷慨指导后获得全场起立鼓掌。', ['recent','dishonest','careless','ordinary','noisy','temporary'], ['新近的','不诚实的','粗心的','普通的','嘈杂的','暂时的']),
 'venerate': ('Many villagers venerate their ancestors by cleaning family graves and presenting flowers during the annual ceremony.', '许多村民在年度仪式中清扫祖坟并献花，以此崇敬祖先。', ['ignore','imitate','fear','criticize','replace','question'], ['忽视','模仿','害怕','批评','取代','质疑']),
 'venial': ('The judge treated the minor mistake as a venial offense because it caused no harm and was corrected immediately.', '法官认为这个小错误是可宽恕的过失，因为它没有造成伤害且立即得到纠正。', ['fatal','severe','chronic','malicious','permanent','illegal'], ['致命的','严重的','长期的','恶意的','永久的','非法的']),
 'venom': ('The snake injected venom into the mouse through its fangs, quickly paralyzing the small animal.', '蛇用毒牙将毒液注入老鼠体内，很快使这只小动物瘫痪。', ['saliva','blood','antivenom','sweat','mucus','medicine'], ['唾液','血液','抗毒血清','汗液','黏液','药物']),
 'venous': ('The surgeon examined Venous blood returning to the heart, noting its darker color and slower flow.', '外科医生检查回流心脏的静脉血，注意到它颜色较深且流速较慢。', ['arterial','skeletal','cutaneous','respiratory','digestive','neural'], ['动脉的','骨骼的','皮肤的','呼吸的','消化的','神经的']),
 'vent': ('Warm air escaped through the ceiling vent while the building’s heating system operated during the winter.', '冬季建筑供暖系统运行时，暖空气从天花板通风口逸出。', ['window','valve','staircase','chimney','doorway','filter'], ['窗户','阀门','楼梯','烟囱','门口','过滤器']),
 'ventilate': ('The nurse opened both windows to ventilate the room after disinfectant fumes became uncomfortably strong.', '消毒剂气味变得令人不适后，护士打开两扇窗户给房间通风。', ['seal','darken','heat','decorate','flood','compress'], ['密封','使变暗','加热','装饰','淹没','压缩']),
 'ventilation': ('The laboratory installed better ventilation after measurements showed that chemical vapors were accumulating near the ceiling.', '测量显示化学蒸气在天花板附近积聚后，实验室安装了更好的通风系统。', ['insulation','decoration','illumination','foundation','transportation','irrigation'], ['隔热','装饰','照明','地基','运输','灌溉']),
 'venture': ('The young company began a risky venture to develop solar equipment for remote villages without reliable electricity.', '这家年轻公司开始了一项有风险的事业，为缺乏可靠电力的偏远村庄开发太阳能设备。', ['routine','shelter','lecture','argument','festival','shortcut'], ['日常事务','避难所','讲座','争论','节日','捷径']),
 'venue': ('The organizers changed the concert venue after heavy rain made the original outdoor field unsafe for visitors.', '大雨使原户外场地对游客不安全后，组织者更换了音乐会举办地点。', ['audience','performer','ticket','instrument','schedule','souvenir'], ['观众','表演者','门票','乐器','日程','纪念品']),
 'ver': ('The inscription uses ver to indicate that the statement claims to describe a real and true condition.', '铭文使用ver表示该陈述声称描述真实情况。', ['false','near','above','early','inside','again'], ['虚假的','附近','上方','早期','里面','再次']),
 'vera': ('Vera is a common female name in several European countries, including Russia and Italy.', 'Vera是俄罗斯和意大利等几个欧洲国家常见的女性名字。', ['Paris','tiger','rose','river','winter','silver'], ['巴黎','老虎','玫瑰','河流','冬天','银色']),
 'veracious': ('The veracious witness gave the same accurate account in court despite repeated questions from the opposing lawyer.', '这位诚实的证人在法庭上尽管被对方律师反复提问，仍给出相同准确陈述。', ['verbose','vicious','voracious','evasive','careless','fictional'], ['冗长的','恶毒的','贪婪的','闪躲的','粗心的','虚构的']),
 'veracity': ('The editor checked the veracity of the historical claim against letters, records, and independently dated photographs.', '编辑用信件、记录和独立标注日期的照片核查这项历史说法的真实性。', ['velocity','variety','vanity','volume','density','brevity'], ['速度','多样性','虚荣','体积','密度','简洁']),
 'verb': ('In the sentence “Birds fly,” fly is a verb because it describes an action performed by the subject.', '在“Birds fly”中，fly是动词，因为它描述主语执行的动作。', ['noun','adjective','adverb','pronoun','article','conjunction'], ['名词','形容词','副词','代词','冠词','连词']),
 'verbal': ('The two companies reached a verbal agreement during the meeting but planned to sign a written contract later.', '两家公司在会议期间达成口头协议，但计划稍后签署书面合同。', ['written','silent','visual','physical','financial','musical'], ['书面的','沉默的','视觉的','身体的','财务的','音乐的']),
 'verbose': ('The verbose report repeated simple points across many pages, making the main recommendation difficult to locate.', '这份冗长报告在许多页中重复简单观点，使主要建议难以找到。', ['concise','silent','fragile','ancient','cautious','formal'], ['简洁的','沉默的','脆弱的','古老的','谨慎的','正式的']),
 'verdant': ('The hikers entered a verdant valley where thick green grass and young trees covered the slopes after spring rains.', '春雨后，徒步者进入翠绿山谷，浓密绿草和幼树覆盖着山坡。', ['barren','metallic','crowded','frozen','dusty','urban'], ['贫瘠的','金属的','拥挤的','冰冻的','尘土飞扬的','城市的']),
 'verdict': ('After reviewing the evidence for three days, the jury returned a verdict that cleared the defendant.', '陪审团审查证据三天后作出裁决，宣告被告无罪。', ['evidence','witness','sentence','appeal','hearing','contract'], ['证据','证人','判决','上诉','听证','合同']),
 'verge': ('The wildflowers grew along the verge beside the country road, just beyond the painted edge line.', '野花生长在乡间道路边缘，位于涂有边线的外侧。', ['center','summit','basement','island','ceiling','entrance'], ['中心','顶峰','地下室','岛屿','天花板','入口']),
 'verifiable': ('The researcher required verifiable evidence, such as dated measurements and archived records, before accepting the claim.', '研究者要求有日期的测量和存档记录等可证实证据后才接受该说法。', ['imaginary','private','accidental','decorative','temporary','emotional'], ['想象的','私人的','偶然的','装饰的','暂时的','情绪化的']),
}
for n in (885,886,887):
    claim=json.loads((root/f'batch-{n:04d}-claim.json').read_text())
    out=[]
    for it in claim['items']:
        e=it['source']['english']; sent,cn,en,zh=extra[e]
        overrides={
            'vcd':'During the 1990s, families often used a VCD player to watch films at home before streaming became common on family television sets.',
            'venerate':'Many villagers venerate their ancestors by cleaning family graves and presenting flowers during the annual ceremony each spring, held by local historians.',
            'vera':'Vera is a common female given name in several European countries, including Russia and Italy, according to naming records in official civil archives.',
        }
        if e in overrides:
            sent=overrides[e]
        if len(sent.split()) < 22:
            sent=sent.rstrip('.')+' in many homes and community centers at that time.'
        if len(sent.split()) < 22:
            sent=sent.rstrip('.')+' before digital streaming became common.'
        out.append({'item_id':it['item_id'],'result':{'english':e,'recognition_distractors':zh,'recognition_explanation_zh':f'题目要求辨认“{it["source"]["chinese"]}”，其余选项分别表示不同概念。','context_sentence':sent,'context_translation_zh':cn,'context_distractors':en,'context_explanation_zh':f'这里的具体情节与“{it["source"]["chinese"]}”相符，其他选项放入句中会改变原意。'}})
    (root/f'batch-{n:04d}-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
