import json

import question_authoring as authoring
import simple_web_app as web

service = authoring.QuestionAuthoringService(web.gaokao_question_sources, web._current_gaokao_source)
for kind, worker in (
    ("generation", "codex-legacy-oct02-new-author"),
    ("revision", "codex-legacy-oct01-author"),
    ("recognition_blind", "codex-legacy-oct01-recognition"),
    ("context_blind", "codex-legacy-oct01-context"),
    ("feedback", "codex-legacy-oct01-feedback"),
):
    result = service.pending({"kind": kind, "worker_id": worker, "level": "", "limit": 10, "ttl_seconds": 86400})
    print(json.dumps({"kind": kind, "has_more": result["has_more"], "items": result["items"]}, ensure_ascii=False))
