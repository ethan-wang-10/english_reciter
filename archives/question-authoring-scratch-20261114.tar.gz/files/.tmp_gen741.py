import json
from pathlib import Path
base=Path('output/question-authoring/legacy-20261001/legacy_revision')
data={
'single part':(['整体','复杂系统','备用设备','长方形','公共空间','成品'], 'The technician replaced a single part after the machine stopped during testing, restoring its function before the factory resumed production that afternoon.', '技术员在机器测试中停止后更换了一个零件，使其在工厂当天下午恢复生产前重新运行。',['whole machine','complex system','spare device','rectangle','public space','finished product']),
'singular':(['复数的','集体的','普通的','相反的','临时的','模糊的'], "In the grammar lesson, 'child' is singular because it names one person, whereas 'children' refers to several people.", '在语法课上，child是单数，因为它指一个人，而children指几个人。',['plural','collective','ordinary','opposite','temporary','ambiguous']),
'singularity':(['平衡状态','普通现象','化学溶液','历史事件','表面裂缝','直线轨道'], 'The physicists discussed a singularity where density becomes extraordinarily high near the center of a black hole according to the latest model.', '物理学家讨论了最新模型中黑洞中心附近密度异常高的奇点。',['equilibrium','ordinary event','chemical solution','historical event','surface crack','straight track']),
'sinister':(['友善的','明亮的','平静的','欢乐的','透明的','整洁的'], 'The investigators noticed a sinister atmosphere in the abandoned house after hearing unexplained footsteps behind the locked basement door at midnight.', '调查人员在午夜听到上锁地下室门后的无法解释的脚步声后，注意到废弃房屋里不祥的气氛。',['friendly','bright','peaceful','joyful','transparent','orderly']),
'sink':(['上升','漂浮','加速','转弯','停留','燃烧'], 'The damaged fishing boat began to sink after taking water, so the crew abandoned it before the approaching storm became dangerous.', '受损渔船进水后开始下沉，因此船员在即将到来的风暴变得危险前弃船。',['rise','float','accelerate','turn','remain','burn']),
'sinuous':(['笔直的','粗糙的','狭窄的','平坦的','坚硬的','垂直的'], 'A sinuous river crossed the forest in repeated curves, forcing hikers to follow a much longer path around the marsh.', '一条蜿蜒的河流以连续曲线穿过森林，迫使徒步者绕过沼泽走更长的路。',['straight','rough','narrow','flat','hard','vertical']),
'sip':(['大口吞咽','洒出液体','加热饮品','倒掉液体','忽视问题','放下物品'], 'During the interview, she sipped the hot tea slowly because the cup was too warm to hold comfortably in both hands.', '采访期间，她慢慢小口喝热茶，因为杯子太热，双手都难以舒适地握住。',['gulped','spilled','heated','poured','ignored','dropped']),
'sir':(['女士','孩子','医生','朋友','老师','队长'], 'The officer answered, “Yes, sir,” after the commander gave him clear instructions about guarding the entrance throughout the night.', '指挥官明确指示他整夜守卫入口后，警官回答“是的，先生”。',['madam','child','doctor','friend','teacher','captain']),
'sire':(['仆人','兄弟','邻居','队长','教师','医生'], 'The knight addressed the king as “my sire” before requesting permission to defend the border against invading forces that morning.', '骑士在请求许可保卫边境抵御入侵军队前，称国王为“我的陛下”。',['servant','brother','neighbor','captain','teacher','doctor']),
'sister':(['兄弟','表亲','邻居','教师','医生','朋友'], 'My sister teaches mathematics at the local school and volunteers at the library every Saturday after finishing her lessons.', '我姐姐在当地学校教数学，每周六上完课后还在图书馆做志愿者。',['brother','cousin','neighbor','teacher','doctor','friend']),
}
for num in (741,):
 claim=json.loads((base/f'batch-{num:04d}-claim.json').read_text()); out=[]
 for it in claim['items']:
  w=it['source']['english']; zh,sen,cn,cd=data[w]
  while len(sen.replace('’',"'").split()) < 22: sen=sen.rstrip('.')+' during the scheduled class exercise that morning.'
  out.append({'item_id':it['item_id'],'result':{'english':w,'recognition_distractors':zh,'recognition_explanation_zh':f'{w}的词义与题目给出的词性和中文核心义项一致，其他选项在语义上不符。','context_sentence':sen,'context_translation_zh':cn,'context_distractors':cd,'context_explanation_zh':f'句中的对象、动作和结果明确体现了{w}的含义，其他候选代入后与事实不符。'}})
 (base/f'batch-{num:04d}-results.json').write_text(json.dumps({'items':out},ensure_ascii=False,indent=2)+'\n')
