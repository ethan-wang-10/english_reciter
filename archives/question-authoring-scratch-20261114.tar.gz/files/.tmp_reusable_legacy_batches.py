"""Emit structurally valid, unsubmitted legacy-revision drafts by batch."""

import importlib.util
import json
import re
from pathlib import Path


BASE = Path("output/question-authoring/legacy-20261001/legacy_revision")
spec = importlib.util.spec_from_file_location(
    "legacy_transport", "output/question-authoring/legacy-20261001/transport.py"
)
transport = importlib.util.module_from_spec(spec)
spec.loader.exec_module(transport)

batches = []
for claim_path in sorted(BASE.glob("batch-*-claim.json")):
    match = re.fullmatch(r"batch-(\d+)-claim\.json", claim_path.name)
    if not match:
        continue
    batch = int(match.group(1))
    result_path = claim_path.with_name(claim_path.name.replace("-claim.json", "-results.json"))
    receipt_path = claim_path.with_name(claim_path.name.replace("-claim.json", "-receipt.json"))
    if receipt_path.exists() or not result_path.exists():
        continue
    try:
        claim = json.loads(claim_path.read_text(encoding="utf-8"))
        items = transport.checked(claim, result_path)
    except Exception:
        continue
    if items:
        batches.append(
            {
                "batch": batch,
                "words": [item["result"]["english"] for item in items],
            }
        )

print(json.dumps(batches, ensure_ascii=False))
