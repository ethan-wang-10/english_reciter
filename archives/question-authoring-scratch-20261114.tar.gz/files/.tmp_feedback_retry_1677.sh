#!/bin/sh
set -eu

base='output/question-authoring/audit-20261012/legacy_revision'
mkdir -p "$base"

ssh -4 -o BatchMode=yes -o ConnectTimeout=15 root@english.itorange.online 'cd /data/english_reciter && PYTHONPATH=.:scripts /data/english_reciter/.venv/bin/python -B -c '"'"'
import json, sqlite3, time
import question_authoring_client as client
db = sqlite3.connect("/data/english_reciter/user_data_simple/sessions.sqlite3")
row = db.execute("select token from auth_sessions where session_kind=? and expires_at>? order by expires_at desc limit 1", ("admin", time.time())).fetchone()
if row is None:
    raise SystemExit("no active admin session")
body = {"kind":"legacy_revision","worker_id":"codex-feedback-repair-oct12-1677","request_id":"feedback-repair-1677-claim","level":"","limit":10,"ttl_seconds":86400,"words":["equity","equivalence","equivalent"]}
result = client.request_json(client.DEFAULT_BASE_URL, row[0], "POST", client.API_ROOT + "/claims", body=body, timeout=120)
print(json.dumps(result, ensure_ascii=False, indent=2))
'"'"'' > "$base/batch-1677-claim.json"
