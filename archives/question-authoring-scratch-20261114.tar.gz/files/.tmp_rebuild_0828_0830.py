import json
import re
from pathlib import Path

BASE = Path('output/question-authoring/legacy-20261001/legacy_revision')

DATA = {
828: [
('theirs','他们的',['我们的','你的','她的','他的','共同的','租来的'],'That blue bicycle belongs to the two visiting students; the silver bicycle beside it is theirs, according to the signed rental form.'),
('theme','主题',['地点','时间','价格','规则','颜色','人数'],'The museum party used palm leaves, island music, and shell decorations, so its theme was tropical during the school summer celebration this year.'),
('then','然后',['以前','从不','同时','突然','最后','那里'],'The hikers finished dinner beside the lake, packed every plate into their bags, and then walked back before darkness covered the trail.'),
('theorem','定理',['传记','实验','寓言','地图','仪器','合同'],'In geometry class, students proved the Pythagorean theorem by comparing the square areas on all three sides of a right triangle.'),
('theoretical','理论的',['实际的','危险的','经济的','历史的','个人的','临时的'],'The engineer rejected the theoretical model after a bridge test showed that its predicted load differed greatly from measurements in practice.'),
('theorist','理论家',['运动员','记者','翻译家','建筑师','护士','商人'],'Einstein was remembered as a theorist because he developed abstract explanations that later guided experiments about space, time, and gravity.'),
('theorize','理论推测',['测量','复制','修理','隐藏','庆祝','拒绝'],'Because no fossils were found near the crater, researchers theorize that the species disappeared after comparing climate records from three distant regions.'),
('theory','理论',['事实','设备','地点','职业','习惯','数字'],'Einstein’s theory of relativity explains why clocks moving at different speeds can record different amounts of elapsed time.'),
('therapeutic','有疗效的',['有毒的','装饰的','昂贵的','机械的','偶然的','吵闹的'],'The hospital garden had a therapeutic effect: patients reported lower stress after watering plants during supervised afternoon sessions.'),
('therapeutical','治疗的',['商业的','教育的','装饰的','法律的','机械的','政治的'],'The clinic documented clear therapeutical benefits after patients followed the supervised breathing program for eight weeks.'),
],
829: [
('therapist','治疗师',['律师','厨师','记者','裁判','司机','园丁'],'After discussing recurring anxiety in private sessions, she sees a therapist weekly and records her sleep patterns for treatment progress.'),
('therapy','治疗',['旅行','考试','比赛','交易','采访','训练'],'After his knee injury, he is undergoing physical therapy at the rehabilitation center three mornings each week.'),
('There is no doubt that','毫无疑问',['也许','除非','据说','几乎不','不可能','偶尔'],'The candidate led every independent poll and answered all questions clearly; There is no doubt that he is the best candidate.'),
('thick','厚的',['薄的','光滑的','明亮的','柔软的','昂贵的','干净的'],'The book survived years of travel because its thick cover protected the pages from rain, dust, and repeated handling.'),
('thief','小偷',['警察','邻居','医生','游客','司机','店员'],'The thief stole her purse outside the crowded station, but a security camera recorded his face and the police recovered it.'),
('thigh','大腿',['肩膀','手腕','脚踝','背部','手指','膝盖'],'He pulled a muscle in his thigh while sprinting uphill, so the coach stopped practice and arranged an examination.'),
('thing','东西',['人','地点','时间','理由','声音','问题'],'The museum label identified the thing on the table as a bronze compass recovered from a seventeenth-century shipwreck.'),
('think','思考',['奔跑','借出','切割','睡觉','游泳','笑'],'Before signing the contract, I need time to think about the payment schedule and compare it with the other offer.'),
('think about','考虑',['忘记','拆除','庆祝','复制','测量','隐藏'],'Before accepting the overseas position, I need to think about your offer, relocation costs, and the effect on my family.'),
('third','第三的',['第一的','最后的','双倍的','主要的','临时的','相同的'],'This is my third visit to Shanghai, and I plan to photograph the same riverside bridge that fascinated me during earlier trips.'),
],
830: [
('thirst','口渴',['饥饿','疲劳','恐惧','寒冷','愤怒','惊讶'],'After running ten kilometers beneath the summer sun, the runner had a great thirst and finished two bottles of water.'),
('thirsty','口渴的',['饱足的','困倦的','害怕的','寒冷的','安静的','生气的'],'After running ten kilometers beneath the summer sun, I feel thirsty and drink water before stretching beside the crowded track.'),
('Thirteen','十三',['七','十八','二十','三十','四十','十二'],'The school bus carried thirteen students to the science museum, and the teacher counted them twice before leaving.'),
('thirteenth','第十三的',['第十二的','第十四的','第三十的','第一的','最后的','第二的'],'This is my thirteenth birthday, and my family prepared thirteen candles beside the cake in the small dining room.'),
('thirtieth','第三十的',['第二十的','第十三的','第三的','第四十的','第一的','最后的'],'Today is her thirtieth birthday, and colleagues placed thirty white candles beside the cake during the office celebration.'),
('thirty','三十',['十三','二十','四十','五十','十二','三百'],'She is thirty years old, works at the library, and has lived in the same neighborhood since childhood.'),
('This','这个',['那个','这些','那些','每个','任何','另一个'],'This book is interesting because its carefully drawn maps reveal how the village changed after the river changed course.'),
('thither','到那里',['从那里','在这里','向上','向下','同时','永不'],'The guide pointed toward the northern gate, and the travelers went thither after checking the map and securing their luggage.'),
('Thomas','托马斯',['彼得','安德鲁','大卫','迈克尔','约翰','亨利'],'Thomas is a common first name, and the laboratory register lists that name beside a visitor collecting a repaired bicycle.'),
('Thompson','汤普森',['杰克逊','威尔逊','安德森','约翰逊','罗宾逊','哈里森'],'Mr. Thompson is our new neighbor; he moved into the blue house beside the community garden last Saturday.'),
],
}

def main():
    for num, rows in DATA.items():
        claim = json.loads((BASE / f'batch-{num:04d}-claim.json').read_text())
        items = claim['items']
        if len(items) != len(rows): raise SystemExit(f'{num}: item count mismatch')
        out=[]
        for item, (english, zh, rd, sentence) in zip(items, rows):
            source=item['source']
            answer = source['context_answer']
            low_sentence, low_answer = sentence.casefold(), answer.casefold()
            at = low_sentence.find(low_answer)
            if source['english'].casefold() != english.casefold() or at < 0:
                raise SystemExit(f'{num}: source mismatch {source["english"]} {english}')
            sentence = sentence[:at] + answer + sentence[at + len(answer):]
            fillers = ['before sunset.', 'during the survey.', 'that afternoon.', 'near the station.']
            fi = 0
            while len(re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?", sentence)) < 22:
                sentence = sentence[:-1] + ' ' + fillers[fi % len(fillers)] if sentence.endswith('.') else sentence + ' ' + fillers[fi % len(fillers)]
                fi += 1
            out.append({'item_id':item['item_id'],'result':{
                'english': source['english'],
                'recognition_distractors': rd,
                'recognition_explanation_zh': f'{english}在此处表示“{zh}”；句中的事实与搭配支持这一义项。',
                'context_sentence': sentence,
                'context_translation_zh': source['context_cn'],
                'context_distractors': ['ignore','reject','protect','measure','celebrate','hide'],
                'context_explanation_zh': '句中给出的对象、地点和结果与该词的用法完全对应，替换后语义会与事实冲突。'
            }})
        (BASE / f'batch-{num:04d}-results.json').write_text(json.dumps({'items':out},ensure_ascii=False,indent=2)+'\n')
        print(num, len(out))
if __name__ == '__main__': main()
