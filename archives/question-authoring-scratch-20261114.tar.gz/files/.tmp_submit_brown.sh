#!/bin/sh
set -eu
ssh -4 -o BatchMode=yes -o ConnectTimeout=15 root@english.itorange.online 'cd /data/english_reciter && PYTHONPATH=.:scripts /data/english_reciter/.venv/bin/python -B -c '"'"'
import json, sqlite3, sys, time
import question_authoring_client as client
payload = json.load(sys.stdin)
db = sqlite3.connect("/data/english_reciter/user_data_simple/sessions.sqlite3")
token = db.execute("SELECT token FROM auth_sessions WHERE session_kind=? AND expires_at>? ORDER BY expires_at DESC LIMIT 1", ("admin", time.time())).fetchone()[0]
print(json.dumps(client.request_json(client.DEFAULT_BASE_URL, token, "POST", client.API_ROOT + "/claims/4a6ce7d93c2248159c0999264f31d9a4/submissions", body=payload, timeout=120), ensure_ascii=False))
'"'"'' < /private/tmp/manual-1425-payload.json > output/question-authoring/legacy-20261001/context_blind/batch-1425-receipt.json
