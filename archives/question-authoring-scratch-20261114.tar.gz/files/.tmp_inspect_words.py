import json

import gaokao_questions as questions
import question_authoring as authoring
import simple_web_app as web

keys = [
    "elastic", "elasticity", "elated", "elation", "elbow",
    "eld", "elder", "elderly", "elect", "election",
]
bank = questions._read_bank_keys_unlocked(keys)
view = {}
for key in keys:
    view[key] = {}
    for namespace in ("questions", "candidates", "rejections", "failures"):
        value = bank[namespace].get(key)
        if value is not None:
            meta = authoring._meta(value)
            view[key][namespace] = {
                "state": meta.get("state"),
                "generator_id": meta.get("generator_id"),
                "revision_job_id": meta.get("revision_job_id"),
                "audits": {name: row.get("status") for name, row in meta.get("audits", {}).items()},
            }
print(json.dumps(view, ensure_ascii=False))
sources = {item["english"]: item for item in web.gaokao_question_sources("")}
print(json.dumps({key: sources.get(key) for key in keys}, ensure_ascii=False))
service = authoring.QuestionAuthoringService(web.gaokao_question_sources, web._current_gaokao_source)
print(json.dumps({
    "revision": [item["english"] for item in service._eligible({"kind": "revision", "worker_id": "codex-legacy-oct10-author", "level": "", "limit": 20}, __import__("datetime").datetime.now(__import__("datetime").timezone.utc), 20)],
    "generation": [item["english"] for item in service._eligible({"kind": "generation", "worker_id": "codex-legacy-oct10-author", "level": "", "limit": 20}, __import__("datetime").datetime.now(__import__("datetime").timezone.utc), 20)],
}, ensure_ascii=False))
print(json.dumps({
    "revision_explicit": [item["english"] for item in service._eligible({"kind": "revision", "worker_id": "codex-legacy-oct10-author", "level": "", "limit": 20, "words": keys}, __import__("datetime").datetime.now(__import__("datetime").timezone.utc), 20)],
}, ensure_ascii=False))
from datetime import datetime, timezone
now = datetime.now(timezone.utc)
active = set()
for kind in authoring.JOB_KINDS:
    active.update(service._jobs().active_words(now=now, kind=kind))
print(json.dumps({key: {
    "active": key in active,
    "records": list(authoring._revision_records(bank, key)),
    "in_questions": key in bank["questions"],
    "state": authoring._meta(bank["rejections"].get(key)).get("state"),
    "has_raw": authoring._has_raw(authoring._revision_records(bank, key)),
} for key in keys}, ensure_ascii=False))
import sqlite3
db = sqlite3.connect(str(questions.QUESTION_BANK_FILE.with_name("question_authoring.sqlite3")))
print(json.dumps(db.execute(
    "SELECT l.word_key, j.kind, j.worker_id, j.status, j.expires_at, j.job_id FROM authoring_leases l JOIN authoring_jobs j ON j.job_id=l.job_id WHERE l.word_key IN (%s)" % ",".join("?" * len(keys)), keys
).fetchall(), ensure_ascii=False))
