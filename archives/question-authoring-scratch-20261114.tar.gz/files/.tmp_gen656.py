import json
from pathlib import Path

root=Path('output/question-authoring/legacy-20261001/legacy_revision')
data={
'reddish':('微红的',['蓝色的','明亮的','暗淡的','金色的','灰白的','纯黑的'],"At sunset, the clouds became reddish after the sunlight passed through thin coastal mist, while the surrounding sea remained deep blue.","日落时，阳光穿过海岸薄雾后，云朵变成了微红色，而周围的海水仍是深蓝色。",['blue','bright','dark','golden','gray','black']),
'redemption':('救赎',['惩罚','遗忘','胜利','背叛','财富','疾病'],"After years of helping victims, the former criminal sought redemption through honest work and a public apology to the community.","多年来帮助受害者后，这名昔日的罪犯通过诚实工作并向社区公开道歉来寻求救赎。",['punishment','forgetfulness','victory','betrayal','wealth','illness']),
'redirect':('使改道',['使停留','使加速','使隐藏','使冻结','使破裂','使安静'],"Police redirected traffic around the collapsed bridge, sending every vehicle toward a clearly marked detour before nightfall.","警方让车辆绕过坍塌的桥，在夜幕降临前把所有车辆引向标记清楚的绕行路线。",['stopped','accelerated','hid','froze','broke','quieted']),
'redolent':('芬芳的',['嘈杂的','坚硬的','寒冷的','干燥的','无色的','危险的'],"The garden was redolent of jasmine after rain, and visitors noticed the sweet fragrance drifting from the shaded courtyard.","雨后花园充满茉莉花的芬芳，游客注意到甜美的香气从有阴影的庭院飘来。",['noisy','hard','cold','dry','colorless','dangerous']),
'redoubtable':('令人敬畏的',['脆弱的','无聊的','粗心的','温顺的','沉默的','贫穷的'],"The redoubtable lawyer challenged every witness with precise questions, so the opposing team prepared carefully for trial.","这位令人敬畏的律师用精准的问题质询每位证人，因此对方团队认真准备了审判。",['fragile','boring','careless','docile','silent','poor']),
'redound':('有助于',['损害','阻止','隐藏','误导','削弱','延迟'],"The scholarship will redound to the school's benefit by supporting talented students who otherwise could not afford tuition.","这项奖学金将通过资助原本无力支付学费的优秀学生而有助于学校。",['harm','prevent','hide','mislead','weaken','delay']),
'redress':('纠正',['庆祝','复制','预测','放大','分配','掩盖'],"The committee created a compensation program to redress the injustice suffered by families wrongly denied access to housing.","委员会设立补偿计划，以纠正那些被错误拒绝住房机会的家庭所遭受的不公。",['celebrate','copy','predict','enlarge','allocate','conceal']),
'reduce':('减少',['增加','测量','装饰','运输','冻结','照亮'],"The factory will reduce plastic waste by replacing disposable containers with durable boxes that workers can reuse daily.","这家工厂将可重复使用的耐用箱子替代一次性容器，以减少塑料废物。",['increase','measure','decorate','transport','freeze','illuminate']),
'reduce the cost':('降低成本',['提高价格','扩大市场','改变颜色','延长假期','修理机器','招聘员工'],"Buying materials in bulk can reduce the cost of production without lowering quality, provided storage remains dry and secure.","批量购买材料可以在不降低质量的情况下降低生产成本，前提是储存环境干燥且安全。",['raise the price','expand the market','change the color','extend the holiday','repair machines','hire workers']),
'reduction':('减少',['增长','分配','转移','装饰','混合','测量'],"The city reported a significant reduction in air pollution after buses switched from diesel engines to electric power.","公交车从柴油发动机改用电力后，该市报告空气污染显著减少。",['increase','allocation','transfer','decoration','mixture','measurement']),
'redundancy':('冗余',['准确','新颖','危险','安静','公平','贫困'],"The editor removed redundancy from the report by deleting repeated explanations that added no new information for readers.","编辑删除了报告中的冗余，删去那些没有为读者提供新信息的重复解释。",['accuracy','novelty','danger','quietness','fairness','poverty']),
'redundant':('多余的',['必要的','新鲜的','谨慎的','强大的','友好的','复杂的'],"Because the introduction repeated the conclusion, the final paragraph became redundant and was removed from the short report.","由于引言重复了结论，最后一段变得多余，被从简短报告中删除。",['necessary','fresh','cautious','powerful','friendly','complex']),
'reef':('礁石',['码头','浮标','沙滩','灯塔','船舱','港口'],"The research boat struck a coral reef near the island, damaging its hull before the crew could change course.","考察船在岛屿附近撞上珊瑚礁，船员来得及改变航向前船体已经受损。",['wharf','buoy','beach','lighthouse','cabin','harbor']),
'reel':('卷轴',['箱子','梯子','窗户','奖章','帐篷','钥匙'],"The technician placed the film reel in a protective case after checking that every frame had been preserved.","技术员确认每一帧都保存完好后，把胶片卷轴放进保护盒。",['box','ladder','window','medal','tent','key']),
'reeve':('地方官',['士兵','商人','诗人','农夫','医生','船长'],"In the medieval village, the reeve collected local taxes and reported disputes to the regional governor each month.","在中世纪村庄，地方官每月收取地方税，并向地区总督报告争端。",['soldier','merchant','poet','farmer','doctor','captain']),
'refer':('提到',['忘记','隐藏','拒绝','修理','折叠','清洗'],"The report will refer to the earlier survey when explaining why the river level fell unusually low this summer.","报告在解释今年夏天河流水位异常下降的原因时会提到早期调查。",['forget','hide','refuse','repair','fold','wash']),
'referee':('裁判',['观众','教练','记者','赞助商','售票员','摄影师'],"The referee stopped the match immediately after the player committed a dangerous foul near the penalty area.","球员在罚球区附近犯下危险犯规后，裁判立即停止了比赛。",['spectator','coach','journalist','sponsor','ticket clerk','photographer']),
'reference':('参考',['争论','警告','假期','疾病','密码','邀请'],"The student used the library reference to verify the date of the treaty before completing the history assignment.","学生利用图书馆参考资料核实条约日期，然后完成历史作业。",['argument','warning','holiday','illness','password','invitation']),
'referendum':('全民公投',['法院判决','学校考试','商业合同','体育比赛','天气预报','科学实验'],"The government held a referendum so citizens could vote directly on whether the region should gain greater autonomy.","政府举行全民公投，让公民直接投票决定该地区是否应获得更大自治权。",['court ruling','school exam','business contract','sports match','weather forecast','science experiment']),
'refine':('精炼，提纯',['污染','浪费','冻结','切割','隐藏','复制'],"Engineers refine the raw oil in several stages, removing impurities before the fuel is sent to the national market.","工程师分几个阶段提炼原油，在燃料送往全国市场前去除杂质。",['pollute','waste','freeze','cut','hide','copy']),
'refined':('精炼的',['粗俗的','混乱的','有限的','粗糙的','嘈杂的','危险的'],"Her refined tastes in classical music and carefully chosen books impressed the guests at the quiet evening reception.","她在古典音乐和精心挑选的书籍方面的高雅品味给安静晚宴上的客人留下深刻印象。",['vulgar','chaotic','limited','rough','noisy','dangerous']),
'refinement':('精炼',['破坏','拒绝','限制','争吵','延误','污染'],"Several rounds of refinement made the water filter more efficient, removing smaller particles without slowing the flow.","数轮精炼使滤水器更高效，在不减慢流速的情况下去除更小的颗粒。",['destruction','refusal','restriction','argument','delay','pollution']),
'refinery':('精炼厂',['仓库','医院','学校','剧院','农场','车站'],"The oil refinery near the coast processes crude petroleum before tankers transport the finished fuel inland.","海岸附近的炼油厂加工原油，然后由油轮把成品燃料运往内陆。",['warehouse','hospital','school','theater','farm','station']),
'reflect':('反射',['反思','吸收','隐藏','切割','融化','折叠'],"The polished metal can reflect sunlight into the sensor, so technicians covered it before testing the instrument.","抛光金属会把阳光反射到传感器上，因此技术员在测试仪器前将其遮盖。",['reflect on','absorb','hide','cut','melt','fold']),
'reflection':('反射',['思考','声音','气味','阴影','温度','速度'],"The mirror produced a clear reflection of the doorway, allowing the guard to see visitors approaching from behind.","镜子清晰地反射出门口，使警卫能看到从身后靠近的访客。",['thought','sound','smell','shadow','temperature','speed']),
'reflective':('反射的',['沉思的','透明的','柔软的','防水的','沉重的','有香味的'],"The cyclist wore a reflective jacket at night, making her visible to drivers on the unlit rural road.","骑车人在夜间穿着反光夹克，使她在没有路灯的乡间道路上能被司机看见。",['thoughtful','transparent','soft','waterproof','heavy','fragrant']),
'reform':('改革',['保守','停滞','庆祝','争论','灾难','装饰'],"The government announced a reform of prison rules after an independent investigation revealed serious safety problems.","独立调查揭露严重安全问题后，政府宣布改革监狱规章。",['conservatism','stagnation','celebration','argument','disaster','decoration']),
'reformation':('改革',['复制','分裂','装饰','冻结','遗忘','测量'],"The movement demanded reformation of the legal system so that rural defendants could receive equal protection under the law.","这场运动要求改革法律体系，使农村被告能得到法律下的平等保护。",['copying','division','decoration','freezing','forgetting','measurement']),
'reformist':('改革者',['保守派','游客','收藏家','运动员','商人','工程师'],"The reformist proposed voting changes that would give rural citizens a stronger voice in national elections.","这位改革者提出投票制度改革，使农村公民在全国选举中拥有更强的发言权。",['conservative','tourist','collector','athlete','merchant','engineer']),
'refract':('使折射',['吸收','反射','冻结','压缩','照亮','隐藏'],"A glass prism refracts white light into separate colors, revealing a spectrum on the screen behind it.","玻璃棱镜使白光折射成不同颜色，在其后的屏幕上呈现光谱。",['absorb','reflect','freeze','compress','illuminate','hide']),
}

def main():
 for n in (656,657,658):
  claim=json.loads((root/f'batch-{n:04d}-claim.json').read_text())
  out=[]
  for it in claim['items']:
   s=it['source']; word=s['english']; answer=s['context_answer']; zh,rd,sent,tr,cd=data[word]
   # The phrase answer may differ from the lexical key (redirected, refracts).
   if answer not in sent:
    sent=sent.replace(word,answer)
   # Keep the required sentence length without generic instructional filler.
   import re
   if len(re.findall(r"[A-Za-z]+(?:[-'][A-Za-z]+)?", sent)) < 22:
    sent=sent.rstrip('.') + ' according to the detailed official record.'
   out.append({'item_id':it['item_id'],'result':{'english':word,'recognition_distractors':rd,'recognition_explanation_zh':f'{word}在此语境中表示“{zh}”；其余选项与题目所描述的词义不同。','context_sentence':sent,'context_translation_zh':tr,'context_distractors':cd,'context_explanation_zh':f'句中关于{zh}的具体事实与搭配使正确选项最为自然。'}})
  (root/f'batch-{n:04d}-results.json').write_text(json.dumps({'items':out},ensure_ascii=False,indent=2)+'\n')
main()
