import json
from collections import Counter, defaultdict

import gaokao_questions as questions
import question_authoring as authoring
import simple_web_app as web

sources = web.gaokao_question_sources("")
counts = Counter()
examples = defaultdict(list)
for start in range(0, len(sources), 200):
    group = sources[start:start + 200]
    bank = questions._read_bank_keys_unlocked([source["english"] for source in group])
    for source in group:
        key = source["english"]
        found = False
        for namespace in ("questions", "candidates", "rejections", "failures"):
            value = bank[namespace].get(key)
            if not authoring._meta(value):
                continue
            found = True
            meta = authoring._meta(value)
            state = str(meta.get("state") or "unknown")
            label = f"{namespace}:{state}"
            counts[label] += 1
            if len(examples[label]) < 30:
                examples[label].append(key)
        if not found:
            counts["no_external_record"] += 1
print(json.dumps({"counts": dict(sorted(counts.items())), "examples": dict(sorted(examples.items()))}, ensure_ascii=False), flush=True)
