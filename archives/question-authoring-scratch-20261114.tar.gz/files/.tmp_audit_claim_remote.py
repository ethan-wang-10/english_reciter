import json
import os
import sqlite3
import sys
import time

sys.path[:0] = [".", "scripts"]
import question_authoring_client as client

kind, worker_id, request_id, batch_text, words_json = sys.argv[1:]
words = json.loads(words_json)
db = sqlite3.connect("user_data_simple/sessions.sqlite3")
row = db.execute(
    "select token from auth_sessions where session_kind='admin' and expires_at>? order by expires_at desc limit 1",
    (time.time(),),
).fetchone()
if row is None:
    raise SystemExit("no active admin session")
payload = client.request_json(
    client.DEFAULT_BASE_URL,
    row[0],
    "POST",
    client.API_ROOT + "/claims",
    body={
        "kind": kind,
        "worker_id": worker_id,
        "request_id": request_id,
        "level": "",
        "limit": 10,
        "ttl_seconds": 86400,
        "words": words,
    },
    timeout=120,
)
base = f"output/question-authoring/audit-20261011/{kind}"
os.makedirs(base, exist_ok=True)
path = f"{base}/batch-{int(batch_text):04d}-claim.json"
with open(path, "w", encoding="utf-8") as handle:
    json.dump(payload, handle, ensure_ascii=False, indent=2)
    handle.write("\n")
print(json.dumps(payload, ensure_ascii=False))
