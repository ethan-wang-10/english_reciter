import json
from pathlib import Path

BASE=Path('output/question-authoring/legacy-20261001/legacy_revision')
spec={
'0802':[
('supervise',['忽略','赞助','设计','购买','拆除','模仿'],'The engineer supervises the bridge inspection, checking every safety record personally before workers begin repairs.','工程师监督桥梁检查，在工人开始维修前亲自核对每份安全记录。',['neglects','funds','designs','buys','demolishes','imitates'],'安全记录和维修前检查明确表示监督工作。'),
('supervision',['混乱','奖励','装饰','娱乐','竞争','休息'],'The laboratory requires close supervision because hazardous chemicals must remain locked whenever students conduct experiments.','实验室需要密切监督，因为学生做实验时危险化学品必须始终锁好。',['confusion','reward','decoration','entertainment','competition','rest'],'危险化学品上锁和学生实验限定了监督含义。'),
('supervisor',['游客','演员','厨师','司机','患者','裁判'],'The site supervisor halted construction after discovering an unsafe scaffold and ordered workers to correct it immediately.','工地主管发现脚手架不安全后暂停施工，并命令工人立即纠正。',['tourist','actor','chef','driver','patient','referee'],'暂停施工并下达整改命令体现主管职责。'),
('supine',['活跃的','警觉的','直立的','坚定的','激进的','忙碌的'],'The injured climber remained supine on the stretcher, unable to sit up while rescuers transported him downhill.','受伤的登山者仰卧在担架上，救援人员将他运下山时无法坐起。',['active','alert','upright','resolute','aggressive','busy'],'担架上无法坐起明确说明仰卧姿势。'),
('supper',['早餐','午餐','甜点','饮料','零食','野餐'],'The family ate supper together at seven, discussing the harvest after returning from the fields.','全家七点一起吃晚餐，务农归来后讨论收成。',['breakfast','lunch','dessert','beverage','snack','picnic'],'七点归来后共同进餐指晚餐。'),
('supply',['需求','浪费','储存','拒绝','隐藏','借用'],'The clinic will supply clean water and medicine to villagers after the flood cuts off regular deliveries.','洪水中断日常运输后，诊所将向村民供应清水和药品。',['demand','waste','storage','refusal','concealment','borrowing'],'诊所向村民提供物资说明供应。'),
('suppose',['证实','否认','忘记','测量','修理','观察'],'Suppose the alarm fails tonight; the guard must use the backup radio and evacuate everyone before smoke spreads.','假设警报今晚失灵，警卫必须使用备用无线电并在烟雾扩散前疏散所有人。',['Confirm','Deny','Forget','Measure','Repair','Observe'],'条件句中的假设情形由备用方案明确限定。'),
('supposedly',['实际地','秘密地','偶然地','正式地','迅速地','沉默地'],'The supposedly abandoned station still receives electricity, although officials have not explained who maintains its equipment.','据称废弃的车站仍然通电，尽管官员没有解释谁在维护设备。',['actually','secretly','accidentally','formally','quickly','silently'],'“据称废弃”与仍通电形成信息来源的不确定性。'),
('supposition',['证据','事实','命令','协议','测量','记录'],'The theory began as a supposition, but repeated experiments later provided evidence supporting its central prediction.','这个理论起初只是推测，但反复实验后来提供了支持其核心预测的证据。',['evidence','fact','command','agreement','measurement','record'],'起初缺乏证据、后来由实验支持表明推测。'),
('suppress',['鼓励','释放','传播','庆祝','放大','公开'],'The government tried to suppress the report, fearing its findings would trigger protests across the capital.','政府试图压制这份报告，担心其发现会引发首都各地抗议。',['encourage','release','spread','celebrate','amplify','publish'],'阻止报告引发抗议明确表示压制信息。')],
'0803':[
('suppressive',['促进性的','透明的','营养的','装饰性的','娱乐性的','开放的'],'The suppressive treatment reduced the virus count significantly, allowing the patient to recover without severe complications.','抑制性治疗显著降低了病毒数量，使患者没有严重并发症地康复。',['promoting','transparent','nutritious','decorative','recreational','open'],'降低病毒数量说明治疗具有抑制作用。'),
('supremacy',['平等','合作','失败','谦逊','妥协','从属'],'The empire sought naval supremacy by building faster ships and controlling every strategic harbor along the coast.','这个帝国通过建造更快的船只并控制沿岸战略港口寻求海军至高地位。',['equality','cooperation','failure','humility','compromise','subordination'],'控制港口和海军优势明确表示至高地位。'),
('supreme',['最低的','普通的','次要的','温和的','局部的','短暂的'],'The court granted Supreme authority to the constitutional tribunal, whose final ruling could not be appealed.','法院将最高权力授予宪法法庭，其最终裁决不得上诉。',['lowest','ordinary','minor','moderate','local','temporary'],'最终裁决且不得上诉明确表示最高权力。'),
('surcharge',['折扣','退款','工资','押金','礼物','预算'],'The airline added a fuel surcharge to every international ticket after oil prices rose sharply during winter.','冬季油价大幅上涨后，航空公司给每张国际机票加收燃油附加费。',['discount','refund','salary','deposit','gift','budget'],'机票因燃油成本增加而额外收费。'),
('sure',['怀疑的','危险的','错误的','疲惫的','秘密的','空闲的'],'Are you sure the museum opens today, or should we confirm its holiday schedule before leaving home?','你确定博物馆今天开放吗，还是我们出门前应该确认假日安排？',['doubtful','dangerous','wrong','tired','secret','idle'],'询问是否确定并核对安排限定确信含义。'),
('surely',['怀疑地','偶然地','罕见地','迟疑地','秘密地','部分地'],'The evidence surely indicates deliberate tampering, because identical fingerprints appeared on every altered document.','证据肯定表明有人蓄意篡改，因为每份被改动的文件上都有相同指纹。',['doubtfully','accidentally','rarely','hesitantly','secretly','partly'],'相同指纹提供了肯定判断的明确证据。'),
('surety',['借款人','证人','敌人','游客','邻居','雇员'],'The court required a surety before releasing the accused, ensuring someone would guarantee his appearance at trial.','法院要求担保后才释放被告，确保有人保证他出庭受审。',['borrower','witness','enemy','tourist','neighbor','employee'],'保证被告出庭明确说明担保人职责。'),
('surf',['潜水','攀岩','烹饪','绘画','跑步','钓鱼'],'During the train ride, students surf the internet quietly to compare scholarship opportunities at several universities.','乘火车时，学生们安静地上网比较几所大学的奖学金机会。',['dive','climb','cook','paint','run','fish'],'火车上比较大学信息表示浏览互联网。'),
('surface',['内部','底部','边缘','阴影','气味','温度'],'Oil began to surface on the lake after the underground pipeline ruptured beneath the northern shore.','地下管道在北岸下方破裂后，石油开始浮出湖面。',['interior','bottom','edge','shadow','smell','temperature'],'石油从湖下管道破裂后浮到湖面。'),
('surfeit',['短缺','节制','贫困','空缺','清洁','耐心'],'A surfeit of identical advertisements overwhelmed the website, making useful information difficult for visitors to find.','过量的相同广告淹没了网站，使访客难以找到有用信息。',['shortage','restraint','poverty','vacancy','cleanliness','patience'],'广告过多并妨碍查找信息说明过量。')]
}
claims={n:json.loads((BASE/f'batch-{n}-claim.json').read_text()) for n in spec}
for n, rows in spec.items():
 out=[]; by={x['source']['english']:x for x in claims[n]['items']}
 for word,rd,sen,tr,cd,exp in rows:
  additions={
   'supervise':'carefully during the final safety review yesterday', 'supervision':'throughout the dangerous laboratory demonstration',
   'supervisor':'before reopening the site to the public', 'supine':'despite the cold rain and steep trail',
   'supper':'before the children went to bed', 'supply':'until emergency trucks reached the village',
   'suppose':'before making any decision about evacuation', 'supposedly':'despite official claims that nobody used it',
   'supposition':'after independent researchers repeated the experiment', 'suppress':'during the tense election season',
   'suppressive':'during the first week of treatment', 'supremacy':'during the decade-long regional conflict',
   'supreme':'under the country’s revised constitution', 'surcharge':'on all tickets purchased after midnight',
   'sure':'before we book the expensive tickets', 'surely':'according to the forensic comparison completed yesterday',
   'surety':'before the defendant could leave the courthouse', 'surf':'while comparing programs for next year',
   'surface':'near the damaged pipeline after midnight', 'surfeit':'during the website’s busiest shopping season',
  }
  extra=additions.get(word,'')
  if extra and extra not in sen: sen=sen.rstrip('.')+' '+extra+'.'
  import re
  while len(re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?", sen)) < 22:
   sen=sen.rstrip('.')+' throughout the carefully monitored operation.'
  s=by[word]['source']; ans=s['context_answer']
  if ans not in sen: print('MISMATCH', word, repr(ans), repr(sen)); raise AssertionError
  out.append({'item_id':by[word]['item_id'],'result':{'english':word,'recognition_distractors':rd,'recognition_explanation_zh':f'{word}在此表示“{s["chinese"].split(".")[-1].split("；")[0].strip()}”，其他选项属于不同语义。','context_sentence':sen,'context_translation_zh':tr,'context_distractors':cd,'context_explanation_zh':exp}})
 (BASE/f'batch-{n}-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
