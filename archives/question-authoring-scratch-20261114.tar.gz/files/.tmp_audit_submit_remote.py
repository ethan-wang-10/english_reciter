import importlib.util
import json
import os
import sqlite3
import sys
import time

sys.path[:0] = [".", "scripts"]
import question_authoring_client as client

kind, batch_text, submission_id = sys.argv[1:]
batch = int(batch_text)
base = f"output/question-authoring/audit-20261011/{kind}"
claim_path = f"{base}/batch-{batch:04d}-claim.json"
results_path = f"{base}/batch-{batch:04d}-results.json"
receipt_path = f"{base}/batch-{batch:04d}-receipt.json"
with open(claim_path, encoding="utf-8") as handle:
    claim = json.load(handle)
spec = importlib.util.spec_from_file_location("transport", "output/question-authoring/legacy-20261001/transport.py")
transport = importlib.util.module_from_spec(spec)
spec.loader.exec_module(transport)
items = transport.checked(claim, results_path)
db = sqlite3.connect("user_data_simple/sessions.sqlite3")
row = db.execute(
    "select token from auth_sessions where session_kind='admin' and expires_at>? order by expires_at desc limit 1",
    (time.time(),),
).fetchone()
if row is None:
    raise SystemExit("no active admin session")
try:
    payload = client.request_json(
        client.DEFAULT_BASE_URL,
        row[0],
        "POST",
        client.API_ROOT + "/claims/" + claim["job_id"] + "/submissions",
        body={"worker_id": claim["worker_id"], "submission_id": submission_id, "items": items},
        timeout=120,
    )
except client.ClientError as exc:
    print(json.dumps(exc.response or {"error": str(exc)}, ensure_ascii=False))
    raise SystemExit(2)
with open(receipt_path, "w", encoding="utf-8") as handle:
    json.dump(payload, handle, ensure_ascii=False, indent=2)
    handle.write("\n")
print(json.dumps(payload, ensure_ascii=False))
