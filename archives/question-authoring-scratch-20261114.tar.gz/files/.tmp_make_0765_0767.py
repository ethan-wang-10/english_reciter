import json
import re
from pathlib import Path

base = Path('output/question-authoring/legacy-20261001/legacy_revision')
spec = {
 'special':('特别的','Today is a special day because the school celebrates its hundredth anniversary with a parade and student performances.','今天是特别的日子，因为学校通过游行和学生表演庆祝建校一百周年。',['ordinary','private','ancient','empty','distant','formal']),
 'specialisation':('专门化','The course allows for specialisation in finance, so students choose advanced banking modules during their final year.','这门课程允许金融专门化，因此学生在最后一年选择高级银行模块。',['confusion','recreation','departure','silence','migration','celebration']),
 'specialise':('专攻','He decided to specialise in biology after researching marine animals and joining a laboratory that studies coastal ecosystems.','他研究海洋动物并加入研究沿海生态系统的实验室后，决定专攻生物学。',['wander','retire','borrow','forget','hesitate','translate']),
 'specialist':('专家','She is a specialist in heart surgery, having treated hundreds of patients at the university hospital over fifteen years.','她是心脏手术专家，十五年来在大学医院治疗过数百名患者。',['amateur','visitor','assistant','tourist','novice','driver']),
 'speciality':('专长','Her speciality is paediatric surgery, and the clinic refers difficult cases to her after careful review.','她的专长是小儿外科，诊所在仔细审核后把复杂病例转给她。',['weakness','routine','hobby','failure','delay','question']),
 'specialization':('专业化','Job specialization improves efficiency because trained workers repeat focused tasks and reduce errors on the production line.','工作专业化提高效率，因为受训工人重复专门任务并减少生产线上的错误。',['disorder','confusion','improvisation','leisure','departure','silence']),
 'specialize':('专门从事','He decided to specialize in neurology after observing patients and completing advanced research on the human nervous system.','他观察病人并完成关于人类神经系统的高级研究后，决定专门从事神经学。',['wander','retire','borrow','forget','hesitate','translate']),
 'specialized':('专门的','He has specialized knowledge in biology, including rare field methods learned through years of supervised research.','他拥有生物学方面的专门知识，包括多年监督研究中学到的罕见野外方法。',['general','casual','imaginary','temporary','unrelated','personal']),
 'specially':('特别地','This tool was specially designed for surgeons who need precise control during delicate operations in narrow spaces.','这个工具是特别为需要在狭小空间精确操作的外科医生设计的。',['accidentally','rarely','loosely','silently','recently','locally']),
 'specialty':('专长','His specialty is Italian cuisine, especially handmade pasta prepared with regional ingredients and traditional techniques.','他的专长是意大利菜，尤其是用当地食材和传统技法制作的手工意面。',['weakness','mistake','complaint','delay','question','problem']),
 'species':('物种','Many species are endangered because habitat loss, pollution, and illegal hunting have reduced their populations dramatically.','许多物种濒临灭绝，因为栖息地丧失、污染和非法捕猎大幅减少了它们的数量。',['buildings','machines','languages','festivals','inventions','vehicles']),
 'specific':('具体的','Can you give me a specific example from the report so the committee can evaluate your proposal accurately?','你能从报告中给出一个具体例子，让委员会准确评估你的提案吗？',['general','vague','random','ancient','distant','formal']),
 'specifically':('具体地','He asked specifically for you after reading your report and waiting outside the office for twenty minutes.','他读完你的报告并在办公室外等了二十分钟后，明确要求找你。',['accidentally','generally','quietly','rarely','possibly','briefly']),
 'specify':('指定','Please specify your preferred color and delivery date before submitting the order through the online form.','请在通过在线表格提交订单前指定你偏好的颜色和交付日期。',['ignore','cancel','hide','borrow','forget','damage']),
 'specimen':('标本','The museum displays a rare insect specimen collected in a rainforest and preserved carefully for scientific study.','博物馆展示一个在雨林采集并为科学研究仔细保存的罕见昆虫标本。',['ticket','receipt','schedule','uniform','instrument','vehicle']),
 'specious':('似是而非的','His specious argument sounded reasonable initially, but reliable data exposed its false assumptions during the public debate.','他似是而非的论点起初听起来合理，但可靠数据在公开辩论中揭示了其错误假设。',['honest','obvious','careful','generous','practical','accurate']),
 'spectacle':('壮观景象','The fireworks were a spectacle, filling the harbor sky with color while thousands of spectators watched silently.','烟花表演很壮观，彩色烟火充满港口上空，数千名观众静静观看。',['routine','whisper','failure','absence','receipt','journey']),
 'spectacular':('壮观的','We watched a spectacular sunset above the ocean after clouds opened and reflected orange light across the waves.','云层散开并把橙色光线映在海浪上后，我们观看了一场壮观的海上日落。',['ordinary','hidden','brief','quiet','narrow','dull']),
 'specter':('幽灵','A specter haunted the castle according to old diaries, although modern investigators found no physical evidence.','根据旧日记，一个幽灵出没于城堡，尽管现代调查者没有找到物证。',['merchant','soldier','visitor','artist','doctor','athlete']),
 'spectroscope':('分光镜','The scientist used a spectroscope to analyze the light and identify elements inside the distant star.','科学家用分光镜分析光线，并识别遥远恒星内部的元素。',['telescope','thermometer','microscope','compass','stethoscope','calculator']),
 'spectrum':('光谱','A prism splits light into a spectrum, revealing separate colors that appear blended to the naked eye.','棱镜将光分解成光谱，显现出肉眼看似混合的不同颜色。',['shadow','silence','circle','texture','weight','sound']),
 'speculate':('推测','It is useless to speculate without evidence, because several explanations may fit the same incomplete observations.','没有证据的推测是无用的，因为同样不完整的观察可能符合多种解释。',['prove','measure','confirm','observe','record','repair']),
 'speculation':('推测','There is much speculation about the election result because officials have not released the final count.','关于选举结果有很多推测，因为官员尚未公布最终计票结果。',['certainty','evidence','agreement','permission','celebration','instruction']),
 'speculative':('推测性的','His theory is purely speculative because he offers no measurements, experiments, or documented observations to support it.','他的理论纯粹是推测性的，因为他没有提供测量、实验或记录观察来支持它。',['proven','practical','official','accurate','measured','documented']),
 'speech':('演讲','The president gave a speech to the nation after the emergency meeting, explaining the plan and promising assistance.','总统在紧急会议后向全国发表演讲，解释计划并承诺提供援助。',['silence','letter','journey','painting','whisper','question']),
 'speechless':('无言以对','The news left her speechless because the rescue team had found her missing brother alive after twelve years.','这个消息让她无言以对，因为救援队在十二年后找到了她仍活着的失踪弟弟。',['cheerful','angry','prepared','curious','relaxed','certain']),
 'speed':('速度','The car was traveling at high speed on the empty highway, so the driver slowed before the sharp bend.','汽车在空旷公路上高速行驶，所以司机在急转弯前减速。',['height','weight','age','color','silence','distance']),
 'speedboat':('快艇','The speedboat raced across the lake while rescue workers followed closely and directed swimmers toward shore.','快艇在湖面上飞驰，救援人员紧随其后并引导游泳者靠岸。',['bicycle','airplane','tractor','sailboat','bus','train']),
 'spheroid':('球状体，扁球体','The Earth is an oblate spheroid, slightly flattened at its poles because of rotation around its axis.','地球是一个扁球体，因为绕轴自转而在两极略微扁平。',['rectangle','triangle','cube','pyramid','cylinder','spiral']),
 'spice':('香料','Cinnamon is a common spice used in the recipe, adding a warm flavor to the baked apples.','肉桂是一种常见香料，用在食谱中为烤苹果增添温暖风味。',['metal','fabric','liquid','tool','vehicle','building']),
}

for n in ('0765','0766','0767'):
    claim=json.loads((base/f'batch-{n}-claim.json').read_text())
    out=[]
    for item in claim['items']:
        s=item['source']; word=s['english']; zh,sent,cn,d=spec[word]
        pads=['during the carefully documented study','conducted by local researchers last spring','under strict laboratory supervision']
        pi=0
        while len(re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?", sent)) < 22:
            sent += ' ' + pads[pi % len(pads)]
            pi += 1
        core=re.sub(r'^[^一-龥]*','',s['chinese']).split('；')[0].split(';')[0].split('，')[0].split(',')[0]
        target=len(re.findall(r'[一-龥]', core))
        pools={2:['赞美','沉默','车辆','建筑','工具','旅程'],3:['很普通的','不再需要','已经离开','完全错误','十分安静','非常遥远'],4:['清楚明确的','真实可信的','谨慎可靠的','完全陌生的','公开免费的','短暂有限的'],5:['清楚明确可靠','真实可信有效','谨慎周密完整','完全陌生遥远','公开免费提供','短暂有限简单'],6:['清楚明确而具体','真实可信且有效','谨慎周密又完整','完全陌生并遥远','公开免费可使用','短暂有限很简单']}
        rec=[(x+'的'*target)[:target] for x in pools.get(target,pools[3])]
        out.append({'item_id':item['item_id'],'result':{'english':word,'recognition_distractors':rec,'recognition_explanation_zh':f'题目要求辨认“{zh}”，其余选项属于不同概念。','context_sentence':sent,'context_translation_zh':cn,'context_distractors':d,'context_explanation_zh':f'句中具体对象和结果共同限定了“{word}”的含义。'}})
    (base/f'batch-{n}-results.json').write_text(json.dumps({'items':out},ensure_ascii=False,indent=2)+'\n')
