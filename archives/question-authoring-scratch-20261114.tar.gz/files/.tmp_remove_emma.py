import csv
import json
import os
import re
import uuid

import simple_web_app as web
import wordbank_v2 as v2

_PERSONAL_NAME_LABEL_RE = re.compile(
    r"(?:人名|姓名|姓氏|男名|女名|男子名|女子名|专名|意大利人名|古埃及人名)"
)


def _is_personal_name_only(value):
    parts = [part.strip() for part in re.split(r"[；;]", str(value or "")) if part.strip()]
    return bool(parts) and all(_PERSONAL_NAME_LABEL_RE.search(part) for part in parts)


csv_rows_for_selection = web._read_words_csv_from_path(web.WORDS_CSV_FILE)
keys = {
    v2.normalize_english_key(row.get("english", ""))
    for row in csv_rows_for_selection
    if _is_personal_name_only(row.get("chinese", ""))
}
if len(keys) < 1:
    raise RuntimeError("no personal-name-only entries found")
with v2._interprocess_lock():
    with v2._words_v2_lock, web._words_csv_lock:
        v2_rows = v2._read_words_v2_for_append()
        csv_rows = web._read_words_csv_from_path(web.WORDS_CSV_FILE)
        new_v2 = [row for row in v2_rows if v2.normalize_english_key(row.get("english", "")) not in keys]
        new_csv = [row for row in csv_rows if v2.normalize_english_key(row.get("english", "")) not in keys]
        removed_v2 = len(v2_rows) - len(new_v2)
        removed_csv = len(csv_rows) - len(new_csv)
        if removed_v2 + removed_csv == 0:
            print(json.dumps({"words": sorted(keys), "removed_v2": 0, "removed_csv": 0, "status": "already_absent"}))
        else:
            backups = []
            for path in (v2.WORDS_V2_FILE, web.WORDS_CSV_FILE):
                backup = path.with_name(path.name + ".before-remove-personal-names-" + uuid.uuid4().hex + ".bak")
                with backup.open("xb") as stream:
                    stream.write(path.read_bytes())
                    stream.flush()
                    os.fsync(stream.fileno())
                backups.append(str(backup))
            v2._write_words_v2_atomic_under_lock(new_v2)
            web._write_words_csv_rows_atomic_under_lock(new_csv)
            print(json.dumps({"words": sorted(keys), "removed_v2": removed_v2, "removed_csv": removed_csv, "backups": backups}))
