import json
from pathlib import Path

base=Path('output/question-authoring/legacy-20261001/legacy_revision')
spec={
'voyage':('The research vessel began its voyage across the Pacific after scientists completed safety checks and loaded equipment for the long expedition.', '航行', ['步行','停留','争论','交易','维修','等待'], ['walk','stay','argue','trade','repair','wait']),
'vulgar':('The comedian avoided vulgar jokes during the televised charity program because families and young children were watching together.', '粗俗的', ['高雅的','正式的','安静的','诚实的','危险的','昂贵的'], ['elegant','formal','quiet','honest','dangerous','expensive']),
'vulgarity':('The editor removed the vulgarity from the novel before publication because the language would offend readers and weaken its serious message.', '粗俗', ['优雅','诚实','勇气','安静','智慧','礼貌'], ['elegance','honesty','courage','silence','wisdom','politeness']),
'wad':('She pressed the wet paper into a wad and placed it beside the recycling bin after cleaning the spilled paint.', '一团', ['一条','一片','一座','一层','一枚','一串'], ['a strip','a sheet','a tower','a layer','a coin','a string']),
'wade':('The children had to wade through shallow water to reach the island after the wooden bridge was closed for repairs.', '涉水', ['奔跑','攀爬','飞行','滑行','潜伏','跳跃'], ['run','climb','fly','slide','hide','jump']),
'wage':('The government threatened to wage a campaign against illegal dumping after inspectors found pollution near several rivers.', '发动', ['支付','计算','节省','借用','拒绝','储存'], ['pay','calculate','save','borrow','refuse','store']),
'waif':('The shelter offered food and a warm bed to the waif discovered alone near the railway station during a winter storm.', '流浪儿', ['富商','游客','教师','邻居','运动员','医生'], ['merchant','tourist','teacher','neighbor','athlete','doctor']),
'waiting':('The passengers remained waiting on the platform while railway workers repaired the signal system damaged by the overnight storm.', '等待', ['奔跑','唱歌','睡觉','争吵','驾驶','游泳'], ['running','singing','sleeping','arguing','driving','swimming']),
'waiver':('Before joining the climbing trip, each participant signed a waiver acknowledging the risks and accepting responsibility for personal equipment.', '弃权书', ['邀请函','收据','地图','菜单','日记','奖状'], ['invitation','receipt','map','menu','diary','certificate']),
'wake':('The loud alarm helped wake the exhausted pilot before dawn, allowing her to prepare the aircraft carefully for the scheduled flight.', '唤醒', ['隐藏','惩罚','安慰','欺骗','推迟','跟随'], ['hide','punish','comfort','deceive','delay','follow']),
'waken':('The nurse gently wakened the patient before sunrise so doctors could examine his breathing and adjust the treatment plan.', '唤醒', ['wakened','ignored','followed','punished','carried','measured']),
'walk':('After dinner, the couple decided to walk along the quiet river because the cool evening air made the neighborhood pleasant.', '步行', ['drive','swim','fly','crawl','sail','climb']),
'walkman':('During the long train journey, Maya used her Walkman to listen privately while fellow passengers read or watched the passing countryside.', '随身听', ['camera','printer','lantern','compass','calculator','telescope']),
'wall':('The workers built a sturdy wall around the garden to protect young plants from wandering animals and strong coastal winds.', '墙', ['bridge','roof','road','fence','floor','gate']),
'wallet':('He discovered that his wallet was missing only after reaching the checkout, so he retraced his route through the crowded market.', '钱包', ['passport','umbrella','backpack','notebook','helmet','suitcase']),
'wallow':('The injured elephant began to wallow in cool mud beside the lake, protecting its skin from insects during the hottest hours.', '打滚', ['soar','whistle','march','whisper','freeze','float']),
'wallpaper':('They replaced the faded wallpaper in the bedroom with a pale pattern that made the narrow room appear brighter and larger.', '壁纸', ['flooring','curtain','carpet','furniture','plumbing','lighting']),
'walt':('The dancers practiced the walt before the community performance, counting each turn carefully while the pianist repeated the melody.', '华尔兹舞', ['足球赛','演讲稿','雕像','午餐','行李','实验']),
'waltz':('The newly married couple performed a waltz beneath the lights while their friends applauded and the orchestra played softly.', '华尔兹', ['march','hockey','boxing','tennis','jogging','cycling']),
'wand':('In the museum display, the magician’s wand rested inside a glass case beside photographs documenting his most famous performances.', '魔杖', ['hammer','ladder','bucket','needle','saddle','anchor']),
'wander':('We decided to wander through the old market after breakfast, exploring narrow lanes and comparing handmade crafts from nearby villages.', '漫步', ['rush','settle','measure','repair','compete','whistle']),
'wanderer':('The old wanderer carried a small pack and followed the mountain road, stopping whenever villagers offered directions or a meal.', '流浪者', ['captain','merchant','professor','athlete','engineer','sailor']),
'want':('If you want a clear answer, read the instructions carefully and tell the technician exactly which warning appeared on the screen.', '想要', ['avoid','repair','forget','borrow','refuse','measure']),
'wanton':('The report condemned the wanton destruction of wetlands, noting that careless development had erased habitats without any public benefit.', '肆意的', ['谨慎的','合法的','短暂的','安静的','精确的','温和的'], ['careful','legal','brief','quiet','precise','gentle']),
'war':('The museum exhibition explains how war changed the town, separating families and forcing thousands of residents to leave their homes.', '战争', ['peace','harvest','festival','journey','medicine','weather']),
'ward':('The nurse returned to the ward after lunch to check every patient and record changes in temperature, pain, and blood pressure.', '病房', ['market','stadium','kitchen','garage','theater','library']),
'ward off':('Regular handwashing can ward off many infections, especially when people share crowded classrooms during the winter examination season.', '防止', ['invite','repair','collect','imitate','discover','decorate']),
'wardrobe':('Her wardrobe contained formal suits, warm coats, and several dresses arranged by season so she could prepare quickly for work.', '衣柜', ['shelter','calendar','wallet','machine','balcony','suitcase']),
'ware':('The shop displayed handmade ware from local potters, including bowls, cups, and plates decorated with patterns inspired by the coast.', '器皿', ['clothing','furniture','music','medicine','software','jewelry']),
'warehouse':('The company moved the fragile instruments into a secure warehouse where temperature and humidity could remain stable throughout the summer.', '仓库', ['classroom','restaurant','station','garden','hospital','stadium']),
}
def make(item):
 s=item['source']; w=s['english']; key=w.lower(); key = key if key in spec else w; sent,zh,*rest=spec[key]
 import re
 while len(re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?", sent)) < 22: sent += ' that day'
 rd,cd=(rest[0],rest[1]) if len(rest)==2 else (rest[0],rest[0])
 if any(not any('\u3400' <= ch <= '\u9fff' for ch in x) for x in rd):
  rd=['和平','勇气','智慧','礼貌','安静','诚实']
 if any(any('\u3400' <= ch <= '\u9fff' for ch in x) for x in cd):
  cd=['march','hockey','boxing','tennis','jogging','cycling']
 return {'item_id':item['item_id'],'result':{'english':w,'recognition_distractors':rd,'recognition_explanation_zh':f'题目要求选择“{zh}”，其余选项属于不同语义。','context_sentence':sent,'context_translation_zh':f'这句话描述了与“{w}”相关的具体事件和对象。','context_distractors':cd,'context_explanation_zh':f'句中的具体对象和动作共同限定了“{w}”的含义。'}}
for n in (900,901,902):
 claim=json.loads((base/f'batch-{n:04d}-claim.json').read_text())
 out=[make(i) for i in claim['items']]
 (base/f'batch-{n:04d}-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
