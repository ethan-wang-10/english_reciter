import json

import gaokao_questions as questions
import question_authoring as authoring
import simple_web_app as web

service = authoring.QuestionAuthoringService(web.gaokao_question_sources, web._current_gaokao_source)
for word in ("crayon", "curiously"):
    source = service.source_lookup(word)
    bank = questions._read_bank_keys_unlocked([word])
    candidate = bank["candidates"].get(word)
    metadata = authoring._meta(candidate)
    audits = metadata.get("audits", {})
    print(json.dumps({
        "word": word,
        "source": bool(source),
        "namespaces": [name for name in ("candidates", "questions", "rejections", "failures") if word in bank[name]],
        "candidate_state": metadata.get("state"),
        "generation_job_id": metadata.get("generation_job_id"),
        "generator_id": metadata.get("generator_id"),
        "author_ids": metadata.get("author_ids"),
        "revision_job_id": candidate.get("revision_job_id") if isinstance(candidate, dict) else None,
        "audits": {name: {field: value.get(field) for field in ("status", "reviewer_id", "audit_version")} for name, value in audits.items() if isinstance(value, dict)},
        "prior": sorted(service._prior(candidate)),
        "eligible_feedback": [item["english"] for item in service._eligible({"kind": "feedback", "worker_id": "codex-legacy-oct01-feedback", "level": "", "limit": 10, "ttl_seconds": 86400, "words": [word]}, __import__("datetime").datetime.now(__import__("datetime").timezone.utc), 10)],
    }, ensure_ascii=False))
