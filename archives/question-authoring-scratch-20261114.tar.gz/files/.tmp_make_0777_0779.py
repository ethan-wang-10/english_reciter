import json
import re
from pathlib import Path

base=Path('output/question-authoring/legacy-20261001/legacy_revision')
spec={
777:[
('standardization','标准化','Standardization','Standardization improves factory consistency, reduces errors, and helps every shift follow the same documented production procedure throughout the busy working day each season.', ['商业化','多样化','个性化','国际化','复杂化','自动化'], ['disruption','variation','privatization','improvisation','fragmentation','confusion']),
('standardize','使标准化','standardize','The committee voted to standardize safety procedures so every laboratory follows identical checks before researchers begin experiments.', ['使商业化','使多样化','使复杂化','使私有化','使自动化','使国际化'], ['customize','complicate','privatize','fragment','separate','ignore']),
('standby','待命状态','standby','The hospital keeps its backup generator on standby throughout storms, ready to supply electricity if the main system fails.', ['站立姿势','旁观态度','独立位置','临时住所','固定装置','工作岗位'], ['departure','silence','failure','motion','storage','repair']),
('stanford','斯坦福大学','Stanford','After receiving a scholarship, Maya chose to study computer science at Stanford and moved to California that autumn.', ['哈佛大学','牛津大学','耶鲁大学','剑桥大学','东京大学','麻省理工'], ['station','stadium','museum','hospital','library','theater']),
('staple','主食','staple','Rice remains a staple in many Asian communities because it is affordable, versatile, and served with vegetables at daily meals.', ['订书钉','装饰品','零食','饮料','调味料','餐具'], ['ornament','document','dessert','beverage','utensil','package']),
('stapler','订书机','stapler','The office assistant used a stapler to fasten the invoices together before placing the complete packet inside the manager’s folder.', ['订书钉','剪刀','胶水','文件夹','打印机','尺子'], ['staple','scissors','glue','folder','printer','ruler']),
('star','星星','star','On the clear mountain evening, we saw a bright star above the ridge while astronomers prepared their telescopes nearby.', ['明星','月亮','云朵','行星','流星','太阳'], ['actor','moon','cloud','planet','meteor','sun']),
('starboard','右舷','starboard','The captain ordered everyone to look toward starboard after the navigation officer spotted a lighthouse beside the vessel’s right side.', ['左舷','船头','船尾','甲板','港口','锚地'], ['port','bow','stern','deck','harbor','anchorage']),
('starfield','星空','starfield','The telescope revealed a dense starfield above the desert, where researchers recorded thousands of distant lights during the silent observation.', ['星云','月面','日落','海岸','森林','云层'], ['nebula','lunar surface','sunset','coastline','forest','cloudbank']),
('stark','荒凉的','stark','After the wildfire, the stark landscape contained blackened trees and empty slopes, with no buildings or vegetation visible for miles.', ['鲜明的','繁茂的','舒适的','拥挤的','温暖的','华丽的'], ['vivid','lush','comfortable','crowded','warm','ornate'])],
778:[
('starry','布满星星的','starry','We gazed at the starry sky from the quiet hilltop while the guide identified constellations and explained their seasonal movements to everyone.', ['多云的','无星的','晴朗的','明亮的','阴暗的','潮湿的'], ['cloudy','empty','clear','bright','dark','damp']),
('starter','开胃菜','starter','The restaurant served mushroom soup as a starter before the main course arrived, giving guests a warm beginning to dinner on that evening.', ['启动器','甜点','主菜','饮料','餐巾','菜单'], ['engine','dessert','main course','beverage','napkin','menu']),
('starvation','饥饿','starvation','During the long drought, aid workers delivered grain to remote villages where starvation had already weakened many families.', ['满足','富裕','庆祝','疾病','睡眠','迁徙'], ['satisfaction','wealth','celebration','illness','sleep','migration']),
('starve','挨饿','starve','Without food or clean water, the stranded hikers would starve before rescuers could reach their isolated mountain shelter.', ['庆祝','休息','欢笑','繁荣','航行','治愈'], ['celebrate','rest','laugh','prosper','sail','heal']),
('stash','藏匿','stashed','He stashed the emergency money under the bed and told nobody about the secret reserve during the difficult winter.', ['展示','花费','借出','丢弃','捐赠','计算'], ['displayed','spent','lent','discarded','donated','counted']),
('state','状态','state','The machine is in a stable state after repairs, allowing technicians to monitor its temperature during the overnight test.', ['州','观点','速度','形状','声音','方向'], ['region','opinion','speed','shape','sound','direction']),
('staten','斯塔滕岛','Staten','The ferry carried visitors to Staten Island before sunset, offering them a clear view of Manhattan across the harbor.', ['曼哈顿','布鲁克林','长岛','火岛','自由岛','康尼岛'], ['Manhattan','Brooklyn','Long Island','Fire Island','Liberty Island','Coney Island']),
('statesman','政治家','statesman','The respected statesman negotiated patiently with rival parties and helped them reach a peaceful agreement after months of public disagreement.', ['科学家','运动员','音乐家','记者','商人','画家'], ['scientist','athlete','musician','journalist','merchant','painter']),
('static','静态的','static','The image remained static on the monitor while the operator checked the cable and restarted the program carefully.', ['动态的','柔软的','透明的','嘈杂的','潮湿的','锋利的'], ['moving','soft','transparent','noisy','wet','sharp']),
('station','车站','station','I will meet you at the train station after work, beside the ticket office near the eastern entrance.', ['车厢','机场','码头','车票','隧道','站台'], ['carriage','airport','pier','ticket','tunnel','platform'])],
779:[
('stationary','静止的','stationary','The car remained stationary at the red light while pedestrians crossed safely and traffic officers directed vehicles through the busy intersection nearby.', ['文具的','移动的','快速的','拥挤的','吵闹的','危险的'], ['stationery','moving','rapid','crowded','noisy','dangerous']),
('stationery','文具','stationery','She bought some stationery, including envelopes and writing paper, before sending invitations for the school’s annual community celebration to local families.', ['静止状态','家具','服装','食品','药品','玩具'], ['stationary','furniture','clothing','food','medicine','toys']),
('statistic','统计数据','statistic','This statistic shows a clear trend in rainfall, helping researchers compare each region across the past twenty years.', ['雕像','法律','故事','地图','仪器','计划'], ['statue','statute','story','map','instrument','plan']),
('statistics','统计数字','statistics','The statistics show a rise in unemployment after the factory closed, prompting officials to expand training programs for workers.', ['雕像群','法律条文','预测','传闻','照片','访谈'], ['statues','statutes','predictions','rumors','photographs','interviews']),
('statue','雕像','statue','There is a statue in the park honoring local nurses, surrounded by flowers and a small plaque describing their service.', ['雕塑家','壁画','喷泉','花坛','纪念品','建筑'], ['sculptor','mural','fountain','flowerbed','souvenir','building']),
('statuesque','雕像般优美的','statuesque','The statuesque model stood tall beneath the studio lights, maintaining an elegant posture throughout the photographer’s careful portrait session.', ['姿态笨拙的','动作迟缓的','体态臃肿的','神情疲惫的','外表普通的','身形矮小的'], ['short','awkward','lively','messy','pale','noisy']),
('stature','身高','stature','He is of average stature for his age, although years of swimming have made his shoulders especially broad.', ['声望','年龄','体重','速度','力量','性格'], ['reputation','age','weight','speed','strength','character']),
('status','地位','status','She has a high social status because of her public service, yet she treats every neighbor with equal respect.', ['状态','速度','收入','年龄','距离','方向'], ['condition','speed','income','age','distance','direction']),
('statute','法令','statute','The new statute takes effect next month and requires every company to report workplace injuries within twenty-four hours.', ['雕像','合同','建议','故事','通知','协议'], ['statue','contract','suggestion','story','notice','agreement']),
('statutory','法定的','statutory','There is a statutory requirement for employers to provide safety training before new workers begin handling industrial equipment.', ['自愿的','临时的','私人性质的','传统的','口头的','可选的'], ['voluntary','temporary','private','traditional','oral','optional'])]}

for n, rows in spec.items():
    claim=json.loads((base/f'batch-{n:04d}-claim.json').read_text())
    out=[]
    for item, row in zip(claim['items'], rows):
        w, zh, ans, sent, rd, cd=row
        count=len(re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?", sent))
        if count < 22:
            sent=sent[:-1] + ' during the official review process today.'
        out.append({'item_id':item['item_id'],'result':{'english':w,'recognition_distractors':rd,'recognition_explanation_zh':f'题目要求选择“{zh}”，其余选项属于不同概念。','context_sentence':sent,'context_translation_zh':sent.replace(ans,zh),'context_distractors':cd,'context_explanation_zh':f'句中具体对象、动作和结果明确限定了“{ans}”的含义。'}})
    (base/f'batch-{n:04d}-results.json').write_text(json.dumps({'items':out},ensure_ascii=False,indent=2)+'\n')
