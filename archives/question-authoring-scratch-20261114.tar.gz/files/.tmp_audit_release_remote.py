import json
import sqlite3
import sys
import time

sys.path[:0] = [".", "scripts"]
import question_authoring_client as client

job_id, worker_id = sys.argv[1:]
db = sqlite3.connect("user_data_simple/sessions.sqlite3")
row = db.execute(
    "select token from auth_sessions where session_kind='admin' and expires_at>? order by expires_at desc limit 1",
    (time.time(),),
).fetchone()
if row is None:
    raise SystemExit("no active admin session")
payload = client.request_json(
    client.DEFAULT_BASE_URL,
    row[0],
    "POST",
    client.API_ROOT + "/claims/" + job_id + "/release",
    body={"worker_id": worker_id},
    timeout=120,
)
print(json.dumps(payload, ensure_ascii=False))
