import json
from datetime import datetime, timezone

import question_authoring as authoring
import simple_web_app as web

service = authoring.QuestionAuthoringService(web.gaokao_question_sources, web._current_gaokao_source)
params = {
    "kind": "revision",
    "worker_id": "codex-legacy-oct09-repair",
    "level": "",
    "limit": 10,
    "ttl_seconds": 86400,
}
items = service._eligible(params, datetime.now(timezone.utc), 10)
print(json.dumps([
    {"english": item["english"], "mode": item.get("mode"), "records": sorted(item.get("previous_records", {}))}
    for item in items
], ensure_ascii=False), flush=True)
