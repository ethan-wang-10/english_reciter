#!/bin/sh
set -eu

base='output/question-authoring/audit-20261013/legacy_revision'

python3 -c 'import json; data=json.load(open("output/question-authoring/audit-20261013/legacy_revision/batch-1754-results.json")); print(json.dumps({"worker_id":"codex-feedback-repair-oct13-1754","submission_id":"feedback-repair-1754-submit","items":data["items"]},ensure_ascii=False))' |
ssh -4 -o BatchMode=yes -o ConnectTimeout=15 root@english.itorange.online 'cd /data/english_reciter && PYTHONPATH=.:scripts /data/english_reciter/.venv/bin/python -B -c '"'"'
import json, sqlite3, sys, time
import question_authoring_client as client
payload = json.load(sys.stdin)
db = sqlite3.connect("/data/english_reciter/user_data_simple/sessions.sqlite3")
row = db.execute("select token from auth_sessions where session_kind=? and expires_at>? order by expires_at desc limit 1", ("admin", time.time())).fetchone()
if row is None:
    raise SystemExit("no active admin session")
result = client.request_json(client.DEFAULT_BASE_URL, row[0], "POST", client.API_ROOT + "/claims/52e2f0666aae46de82a9b9b22696db93/submissions", body=payload, timeout=120)
print(json.dumps(result, ensure_ascii=False, indent=2))
'"'"'' > "$base/batch-1754-receipt.json"
